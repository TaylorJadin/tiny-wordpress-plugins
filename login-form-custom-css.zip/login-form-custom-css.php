<?php
/**
* Plugin Name: Add custom CSS to login form
* Plugin URI: https://github.com/TaylorJadin/tiny-wordpress-plugins
* Description: This plugin adds custom CSS to the login form
* Version: 1.0
* Author: Taylor Jadin
* Author URI: https://jadin.me/
**/
function login_form_custom_css() {
    echo '<style type="text/css">
	  #loginform > p:nth-child(1) {display: none;}
	  #loginform > div.user-pass-wrap {display: none;}
	  #loginform > p.forgetmenot {display: none;}
	  #loginform > p.submit {display: none;}
	  #nsl-custom-login-form-main .nsl-container-login-layout-below {padding: 0px !important;}
	</style>';
}
add_action('login_head', 'login_form_custom_css');
?>